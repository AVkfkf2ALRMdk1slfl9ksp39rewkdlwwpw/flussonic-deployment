{application,decklink,
             [{description,"decklink"},
              {vsn,"1"},
              {registered,[]},
              {applications,[kernel,stdlib,erlmedia]},
              {env,[]},
              {modules,[decklink,decklink_push,decklink_pusher]}]}.
