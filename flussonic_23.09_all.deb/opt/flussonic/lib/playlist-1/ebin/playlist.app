{application,playlist,
             [{description,"playlist"},
              {vsn,"1"},
              {registered,[]},
              {applications,[stdlib,kernel,live,vod]},
              {env,[]},
              {modules,[playlist,playlist_onlyvod]}]}.
