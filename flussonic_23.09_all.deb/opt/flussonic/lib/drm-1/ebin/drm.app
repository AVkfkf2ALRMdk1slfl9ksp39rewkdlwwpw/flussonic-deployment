{application,drm,
             [{description,"drm"},
              {vsn,"1"},
              {registered,[]},
              {applications,[stdlib,kernel,public_key,xmerl,corelib]},
              {mod,{drm_app,[]}},
              {env,[]},
              {modules,[drm,drm_app,drm_key,drm_sup]}]}.
