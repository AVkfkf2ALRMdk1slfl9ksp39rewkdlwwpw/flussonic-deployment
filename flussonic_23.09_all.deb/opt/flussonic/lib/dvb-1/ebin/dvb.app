{application,dvb,
             [{description,"dvb"},
              {vsn,"1"},
              {registered,[]},
              {applications,[stdlib,kernel,corelib]},
              {mod,{dvb_app,[]}},
              {env,[]},
              {modules,[dvb_app,dvb_fe,dvb_pusher,dvb_sup,dvb_v4l]}]}.
