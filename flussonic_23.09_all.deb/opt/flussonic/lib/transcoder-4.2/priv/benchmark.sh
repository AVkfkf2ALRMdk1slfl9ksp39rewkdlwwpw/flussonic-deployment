#!/bin/sh

export ERL_CRASH_DUMP_SECONDS=0

if [ -d _build/default/lib ]; then
  export ERL_LIBS=_build/default/lib
elif [ -d /opt/flussonic/lib ]; then
  export ERL_LIBS=/opt/flussonic/lib
  export PATH=/opt/flussonic/bin:$PATH
fi

CONFIG="/opt/flussonic/lib/transcoder/priv/benchmark.config"
NODENAME='benchmark@server.l'
while [ ! -z "$1" ]; do
  case "$1" in
    "-name")
      NODENAME="$2"
      shift
      ;;
    *)
      break
  esac
  shift
done


FLAGS="+zdbbl 65536"
exec erl $FLAGS -name $NODENAME -boot start_sasl -sasl errlog_type all -s transcoder_benchmark start """ $* """

