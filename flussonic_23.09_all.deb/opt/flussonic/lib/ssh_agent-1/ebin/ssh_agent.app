{application,ssh_agent,
             [{description,"SSH reverse proxy agent"},
              {vsn,"1"},
              {registered,[]},
              {applications,[kernel,stdlib,cowboy,rproxy,lhttpc,corelib]},
              {mod,{ssh_agent_app,[]}},
              {env,[{service,"flussonic-ssh-agent"}]},
              {modules,[ssh_agent_app,ssh_agent_sup,support_ssh_agent]}]}.
